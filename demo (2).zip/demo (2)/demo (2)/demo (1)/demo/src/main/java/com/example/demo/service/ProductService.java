package com.example.demo.service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final EmailService emailService;
    private final GoogleSheetsService googleSheetsService;

    @Value("${stock.alert.threshold:2}")
    private int stockThreshold;

    public ProductService(ProductRepository productRepository,
                          EmailService emailService,
                          GoogleSheetsService googleSheetsService) {
        this.productRepository = productRepository;
        this.emailService = emailService;
        this.googleSheetsService = googleSheetsService;
        System.out.println("✅ ProductService started. GoogleSheetsService available: " + (googleSheetsService != null));
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public Product createProduct(Product product) {
        try {
            product.setCreatedDate(LocalDateTime.now());
            product.setUpdatedDate(LocalDateTime.now());

            if (product.getStatus() == null) product.setStatus("ACTIVE");
            product.calculateTotalPrice();

            if (productRepository.existsByProductName(product.getProductName())) {
                throw new RuntimeException("Product '" + product.getProductName() + "' already exists");
            }

            Product savedProduct = productRepository.save(product);
            System.out.println("💾 Product saved: " + savedProduct.getProductName() +
                    " | Stock: " + savedProduct.getUnitStockQuantity());

            // ✅ force check after saving to ensure ID and data are correct
            checkAndAlertLowStock(savedProduct);

            // Export to Google Sheets
            if (googleSheetsService != null) {
                try {
                    googleSheetsService.exportProductToSheet(savedProduct);
                } catch (Exception e) {
                    System.err.println("⚠ Failed to export to Google Sheets: " + e.getMessage());
                }
            }

            return savedProduct;
        } catch (Exception e) {
            throw new RuntimeException("❌ Error saving product: " + e.getMessage());
        }
    }

    public Product updateProduct(Long id, Product productDetails) {
        Optional<Product> optionalProduct = productRepository.findById(id);
        if (optionalProduct.isEmpty()) return null;

        Product product = optionalProduct.get();
        Integer oldStock = product.getUnitStockQuantity();

        if (productDetails.getProductName() != null &&
                !productDetails.getProductName().equals(product.getProductName()) &&
                productRepository.existsByProductName(productDetails.getProductName())) {
            throw new RuntimeException("Product with name '" + productDetails.getProductName() + "' already exists");
        }

        if (productDetails.getProductName() != null) product.setProductName(productDetails.getProductName());
        if (productDetails.getModel() != null) product.setModel(productDetails.getModel());
        if (productDetails.getPricePerQuantity() != null)
            product.setPricePerQuantity(productDetails.getPricePerQuantity());
        if (productDetails.getUnitStockQuantity() != null)
            product.setUnitStockQuantity(productDetails.getUnitStockQuantity());
        if (productDetails.getStatus() != null) product.setStatus(productDetails.getStatus());

        product.calculateTotalPrice();
        product.setUpdatedDate(LocalDateTime.now());

        Product updatedProduct = productRepository.save(product);
        System.out.println("✏ Product updated: " + updatedProduct.getProductName() +
                " | New stock: " + updatedProduct.getUnitStockQuantity());

        // ✅ Ensure alert triggers every time stock ≤ threshold
        checkAndAlertLowStock(updatedProduct);

        // Export to Google Sheets
        if (googleSheetsService != null) {
            try {
                googleSheetsService.exportProductToSheet(updatedProduct);
            } catch (Exception e) {
                System.err.println("⚠ Google Sheets export failed: " + e.getMessage());
            }
        }

        return updatedProduct;
    }

    // ORDER PROCESSING METHOD - NEW
    public Product processOrder(String productName, String model, Integer quantity) {
        Optional<Product> productOpt = productRepository.findByProductNameAndModel(productName, model);

        if (productOpt.isEmpty()) {
            throw new RuntimeException("Product not found with name: " + productName + " and model: " + model);
        }

        Product product = productOpt.get();

        // Check if product is active
        if (!"ACTIVE".equals(product.getStatus())) {
            throw new RuntimeException("Product is not available for ordering. Current status: " + product.getStatus());
        }

        // Check stock availability
        if (product.getUnitStockQuantity() < quantity) {
            throw new RuntimeException("Insufficient stock. Available: " + product.getUnitStockQuantity() + ", Requested: " + quantity);
        }

        // Update stock
        product.setUnitStockQuantity(product.getUnitStockQuantity() - quantity);
        product.setUpdatedDate(LocalDateTime.now());
        product.calculateTotalPrice();

        Product updatedProduct = productRepository.save(product);
        System.out.println("🛒 Order processed: " + quantity + " units of " + productName + " (" + model + ")");
        System.out.println("📦 Remaining stock: " + updatedProduct.getUnitStockQuantity());

        // Check for low stock after order
        checkAndAlertLowStock(updatedProduct);

        // Export to Google Sheets
        if (googleSheetsService != null) {
            try {
                googleSheetsService.exportProductToSheet(updatedProduct);
            } catch (Exception e) {
                System.err.println("⚠ Google Sheets export failed after order: " + e.getMessage());
            }
        }

        return updatedProduct;
    }

    // ✅ This now logs clearly when condition is met
    private void checkAndAlertLowStock(Product product) {
        if (product == null) {
            System.err.println("⚠ Product is null, cannot check stock.");
            return;
        }
        Integer stock = product.getUnitStockQuantity();
        if (stock == null) {
            System.err.println("⚠ Stock quantity is null for product: " + product.getProductName());
            return;
        }

        if (stock <= stockThreshold) {
            System.out.println("🚨 Low stock alert triggered! Product: " +
                    product.getProductName() + " | Stock: " + stock + " | Threshold: " + stockThreshold);
            emailService.sendLowStockAlert(product);
        } else {
            System.out.println("✅ Stock OK for: " + product.getProductName() + " | Stock: " + stock);
        }
    }

    public List<Product> getLowStockProducts() {
        return productRepository.findByUnitStockQuantityLessThanEqual(stockThreshold);
    }

    public void checkAllProductsForLowStock() {
        List<Product> lowStockProducts = getLowStockProducts();
        if (lowStockProducts.isEmpty()) {
            System.out.println("✅ No low-stock products found.");
        } else {
            for (Product product : lowStockProducts) {
                checkAndAlertLowStock(product);
            }
        }
    }

    public boolean deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Scheduled(cron = "0 0 9 * * ?")
    public void scheduledDailyStockCheck() {
        System.out.println("🕘 Running daily low-stock check at " + LocalDateTime.now());
        checkAllProductsForLowStock();
    }
}