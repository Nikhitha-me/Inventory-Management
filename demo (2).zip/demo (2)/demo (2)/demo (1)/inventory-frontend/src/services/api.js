import axios from "axios";

const API_BASE_URL = "http://localhost:8080/api";

// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add request interceptor to include JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle token expiration
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem("token");
      localStorage.removeItem("userData");
      localStorage.removeItem("userType");
      localStorage.removeItem("privileges");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export const authService = {
  // Authentication methods
  login: async (email, password) => {
    try {
      console.log("📤 Sending login request to backend...");
      const response = await api.post("/auth/login", {
        email,
        password,
      });
      console.log("📥 Login response received:", response);
      return response;
    } catch (error) {
      console.error("❌ Auth service login error:", error);
      throw error;
    }
  },

  registerUser: (userData) => api.post("/auth/register/user", userData),
  registerStaff: (staffData) => api.post("/auth/register/staff", staffData),

  // Set authentication data
  setAuth: (token, userData, userType, privileges) => {
    console.log("💾 Setting auth data:", { userType, userData });
    localStorage.setItem("token", token);
    localStorage.setItem("userData", JSON.stringify(userData));
    localStorage.setItem("userType", userType);
    localStorage.setItem("privileges", privileges);
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return localStorage.getItem("token") !== null;
  },

  // Get current user
  getCurrentUser: () => {
    const userData = localStorage.getItem("userData");
    return userData ? JSON.parse(userData) : null;
  },

  // Get user type
  getUserType: () => {
    return localStorage.getItem("userType");
  },

  // Get token
  getToken: () => {
    return localStorage.getItem("token");
  },

  // Logout
  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userData");
    localStorage.removeItem("userType");
    localStorage.removeItem("privileges");
  },
};

// Staff Service
export const staffService = {
  // Get all staff members
  getAll: () => api.get("/staff"),

  // Get staff by ID
  getById: (id) => api.get(`/staff/${id}`),

  // Create new staff member
  create: (staffData) => api.post("/staff", staffData),

  // Update staff member
  update: (id, staffData) => api.put(`/staff/${id}`, staffData),

  // Delete staff member
  delete: (id) => api.delete(`/staff/${id}`),

  // Get staff by status
  getByStatus: (status) => api.get(`/staff/status/${status}`),

  // Check if email exists
  checkEmail: (email) => api.get(`/staff/check-email?email=${email}`),
};

// User Service
export const userService = {
 getAll: () => api.get('/users'),
  getById: (id) => api.get(`/users/${id}`),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  delete: (id) => api.delete(`/users/${id}`),

  // Check if email exists
  checkEmail: (email) => api.get(`/users/check-email?email=${email}`),
};

// Product Service
export const productService = {

    getAll: () => api.get('/products'),
  getById: (id) => api.get(`/products/${id}`),
  // Create new product
  create: (productData) => api.post("/products/staff/create", productData),

  // Update product
  update: (id, productData) =>
    api.put(`/products/staff/update/${id}`, productData),

  // Delete product
  delete: (id) => api.delete(`/products/admin/delete/${id}`),

  // Process order
  processOrder: (orderData) => api.put("/products/order", orderData),

  // Get low stock products
  getLowStock: () => api.get("/products/staff/low-stock"),

  // Manual stock check
  checkStock: () => api.post("/products/staff/check-stock"),

  // Export to Google Sheets
  exportToSheets: () => api.post("/products/staff/export-to-sheets"),

  // Export single product to sheets
  exportSingleToSheets: (id) => api.post(`/products/staff/export-single/${id}`),

  // Check sheets configuration
  checkSheetsConfig: () => api.get("/products/public/sheets-config"),



};

// Public Product Service (no authentication required)
export const publicProductService = {
  // Get all public products
  getAll: () => api.get("/products/public/all"),

  // Get public product by ID
  getById: (id) => api.get(`/products/public/${id}`),

  // Test endpoint
  test: (testData) => api.post("/products/public/test", testData),

  // Debug endpoint
  debug: (rawData) => api.post("/products/public/debug", rawData),
};

// Admin Service (admin-only endpoints)

// services/api.js
export const orderService = {
  placeOrder: (orderData) => api.put('/products/order', orderData),
  getUserOrders: () => api.get('/products/user/my-products'),
};








export const adminService = {
  getAll: () => api.get('/admin'),
  create: (data) => api.post('/admin/create', data),
  delete: (id) => api.delete(`/admin/${id}`),
    bulkUpload: (productsData) =>
  api.post("/products/admin/bulk-upload", productsData),

  // Get all products (admin view)
  getAllProducts: () => api.get("/products/admin/all-products"),
};

export const sheetsService = {
  exportAll: () => api.post('/products/staff/export-to-sheets'),
  exportSingle: (id) => api.post(`/products/staff/export-single/${id}`),
};

export default api;
