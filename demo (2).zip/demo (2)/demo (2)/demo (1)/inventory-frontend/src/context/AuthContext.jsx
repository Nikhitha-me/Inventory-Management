// Update your AuthContext to fix the navigation issue
import React, { createContext, useContext, useState, useEffect } from "react";
import { authService } from "../services/api";

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({
    user: null,
    userType: null,
    rights: null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    console.log("🔄 AuthProvider mounted - checking localStorage");
    const initializeAuth = () => {
      try {
        const token = localStorage.getItem("token");
        const user = localStorage.getItem("user");
        const userType = localStorage.getItem("userType");
        const rights = localStorage.getItem("rights");

        console.log("📦 LocalStorage contents:", {
          token: token ? "exists" : "null",
          user: user ? "exists" : "null",
          userType,
          rights,
        });

        if (token && user) {
          console.log("✅ User found in localStorage, setting auth");
          setAuth({
            user: JSON.parse(user),
            userType: userType,
            rights: rights,
            isAuthenticated: true,
            isLoading: false,
          });
        } else {
          console.log("❌ No user in localStorage");
          setAuth((prev) => ({ ...prev, isLoading: false }));
        }
      } catch (error) {
        console.error("❌ Error initializing auth:", error);
        setAuth((prev) => ({ ...prev, isLoading: false }));
      }
    };

    initializeAuth();
  }, []);

  const login = async (token, userData, userType, rights) => {
    console.log("🔐 AuthContext.login called with:", { userType, userData });
    try {
      // Store in localStorage
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(userData));
      localStorage.setItem("userType", userType);
      localStorage.setItem("rights", rights);

      // Update state
      setAuth({
        user: userData,
        userType: userType,
        rights: rights,
        isAuthenticated: true,
        isLoading: false,
      });
      console.log("✅ Auth state updated successfully");
    } catch (error) {
      console.error("❌ Login error in AuthContext:", error);
      throw error;
    }
  };

  const logout = () => {
    console.log("🚪 Logging out");
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("userType");
    localStorage.removeItem("rights");
    setAuth({
      user: null,
      userType: null,
      rights: null,
      isAuthenticated: false,
      isLoading: false,
    });
  };

  const value = {
    auth,
    login,
    logout,
    // Add these for easier access in components
    isAuthenticated: auth.isAuthenticated,
    isLoading: auth.isLoading,
    user: auth.user,
    userType: auth.userType,
  };

  console.log("🎯 Current Auth State:", auth);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
