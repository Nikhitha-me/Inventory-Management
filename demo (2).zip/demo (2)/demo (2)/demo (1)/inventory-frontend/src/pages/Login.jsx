import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Eye, EyeOff, LogIn, Shield } from "lucide-react";
import LoadingSpinner from "../components/LoadingSpinner";
import { authService } from "../services/api";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();
  const { auth, login, isAuthenticated } = useAuth();

  // Check for success message from registration
  const successMessage = location.state?.message;

  // In your Login component
useEffect(() => {
  console.log("🔍 Login component - Auth state:", auth);

  // Only redirect if user is authenticated and not loading
  if (auth.isAuthenticated && !auth.isLoading) {
    console.log("🎯 User authenticated, redirecting based on:", auth.userType);
    
    // Get the intended destination or use default
    const from = location.state?.from?.pathname;
    
    if (from) {
      console.log("🎯 Redirecting to intended destination:", from);
      navigate(from, { replace: true });
      return;
    }

    // Default redirects based on user type
    switch (auth.userType) {
      case "ADMIN":
        console.log("👑 Redirecting to admin dashboard");
        navigate("/admin/dashboard", { replace: true });
        break;
      case "STAFF":
        console.log("👨‍💼 Redirecting to staff dashboard");
        navigate("/staff/dashboard", { replace: true });
        break;
      case "USER":
        console.log("👤 Redirecting to user dashboard");
        navigate("/user/dashboard", { replace: true });
        break;
      default:
        console.error("❌ Unknown user type for redirect:", auth.userType);
        navigate("/dashboard", { replace: true });
    }
  }
}, [auth.isAuthenticated, auth.isLoading, auth.userType, navigate, location]);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("🚀 Login form submitted");

    if (!validateForm()) return;

    setIsLoading(true);
    setErrors({});

    try {
      console.log("🔐 Attempting login with:", { email: formData.email });

      const response = await authService.login(
        formData.email,
        formData.password
      );

      console.log("✅ Login API response:", response.data);

      const { success, message, token, user, staff, admin } = response.data;

      if (success && token) {
        console.log("🎯 Login successful, processing user data...");

        let userData, userType, rights;

        if (admin) {
          console.log("👑 Admin user detected");
          userData = admin;
          userType = "ADMIN";
          rights = admin.rightsPrivileges || "ADMIN";
        } else if (staff) {
          console.log("👨‍💼 Staff user detected");
          userData = staff;
          userType = "STAFF";
          rights = staff.rightsPrivileges || "BASIC_STAFF";
        } else if (user) {
          console.log("👤 Regular user detected");
          userData = user;
          userType = "USER";
          rights = user.rightsPrivileges || "BASIC_USER";
        } else {
          console.error("❌ No user data in response");
          setErrors({ general: "Login successful but no user data received" });
          setIsLoading(false);
          return;
        }

        console.log("🔄 Calling AuthContext login with:", {
          userType,
          userData,
        });

        // Call AuthContext login - this will update the auth state
        await login(token, userData, userType, rights);

        console.log("✅ AuthContext login completed");
        // Navigation will be handled by the useEffect above
      } else {
        console.error("❌ Login failed in API:", message);
        setErrors({ general: message || "Login failed" });
        setIsLoading(false);
      }
    } catch (error) {
      console.error("❌ Login error:", error);
      let errorMessage = "Login failed. Please try again.";

      if (error.response) {
        // Server responded with error status
        errorMessage = error.response.data?.message || errorMessage;
      } else if (error.request) {
        // Request made but no response received
        errorMessage = "Network error. Please check your connection.";
      }

      setErrors({ general: errorMessage });
      setIsLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name] || errors.general) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
        general: "",
      }));
    }
  };

  // Don't show login form if already authenticated (while redirecting)
  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="text-center">
          <LoadingSpinner />
          <p className="mt-4 text-gray-600">Redirecting...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
            className="mx-auto h-12 w-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-3"
          >
            <Shield className="h-5 w-5 text-white" />
          </motion.div>
          <h2 className="text-xl font-bold text-gray-900 mb-1">Welcome Back</h2>
          <p className="text-gray-600 text-sm">Sign in to your account</p>
        </div>

        {/* Success Message from Registration */}
        {successMessage && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-lg text-sm mb-4"
          >
            {successMessage}
          </motion.div>
        )}

        {/* Main Form Container */}
        <div className="bg-white rounded-xl shadow-lg border p-6">
          {/* Form */}
          <motion.form className="space-y-4" onSubmit={handleSubmit}>
            {errors.general && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm"
              >
                {errors.general}
              </motion.div>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address *
              </label>
              <div className="relative">
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-3 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
                    errors.email
                      ? "border-red-300 focus:ring-red-500"
                      : "border-gray-300"
                  }`}
                  placeholder="Enter your email"
                />
              </div>
              {errors.email && (
                <p className="mt-1 text-xs text-red-600">{errors.email}</p>
              )}
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password *
              </label>
              <div className="relative">
                <input
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  className={`w-full px-3 pr-10 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
                    errors.password
                      ? "border-red-300 focus:ring-red-500"
                      : "border-gray-300"
                  }`}
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-xs text-red-600">{errors.password}</p>
              )}
            </div>

            {/* Submit Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 transition-all shadow-sm mt-2"
            >
              {isLoading ? (
                <LoadingSpinner size="sm" />
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  Sign In
                </>
              )}
            </motion.button>

            {/* Signup Link */}
            <div className="text-center pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-600">
                Don't have an account?{" "}
                <Link
                  to="/signup"
                  className="font-semibold text-blue-600 hover:text-blue-500 transition-colors flex items-center justify-center gap-1"
                >
                  Sign up here
                </Link>
              </p>
            </div>
          </motion.form>
        </div>

        {/* Demo Credentials Hint */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Tip: The system will automatically detect your account type
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;
